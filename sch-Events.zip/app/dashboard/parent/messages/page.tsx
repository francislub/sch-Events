"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Send, User, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"

export default function ParentMessages() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { toast } = useToast()
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const [selectedTeacherId, setSelectedTeacherId] = useState("")
  const [message, setMessage] = useState("")
  const [teachers, setTeachers] = useState<any[]>([])
  const [conversations, setConversations] = useState<any[]>([])
  const [currentMessages, setCurrentMessages] = useState<any[]>([])
  const [isLoadingTeachers, setIsLoadingTeachers] = useState(true)
  const [isLoadingMessages, setIsLoadingMessages] = useState(false)
  const [isSending, setIsSending] = useState(false)

  // Fetch teachers when component mounts
  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login")
      return
    }

    const fetchTeachers = async () => {
      setIsLoadingTeachers(true)
      try {
        const response = await fetch("/api/teachers")
        if (!response.ok) {
          throw new Error(`Failed to fetch teachers: ${response.status}`)
        }

        const data = await response.json()
        console.log("Teachers data:", data)

        if (Array.isArray(data)) {
          setTeachers(data)
        } else {
          console.error("Teachers data is not an array:", data)
          setTeachers([])
        }
      } catch (error) {
        console.error("Error fetching teachers:", error)
        toast({
          title: "Error",
          description: "Failed to load teachers. Please refresh the page.",
          variant: "destructive",
        })
      } finally {
        setIsLoadingTeachers(false)
      }
    }

    const fetchConversations = async () => {
      try {
        const response = await fetch("/api/messages/contacts")
        if (!response.ok) {
          throw new Error(`Failed to fetch conversations: ${response.status}`)
        }

        const data = await response.json()
        console.log("Conversations data:", data)

        if (data.success && Array.isArray(data.data)) {
          setConversations(data.data)
        } else {
          console.error("Conversations data is invalid:", data)
          setConversations([])
        }
      } catch (error) {
        console.error("Error fetching conversations:", error)
        toast({
          title: "Error",
          description: "Failed to load conversations. Please refresh the page.",
          variant: "destructive",
        })
      }
    }

    if (status === "authenticated") {
      fetchTeachers()
      fetchConversations()
    }
  }, [status, router, toast])

  // Fetch messages when a teacher is selected
  useEffect(() => {
    if (!selectedTeacherId) {
      setCurrentMessages([])
      return
    }

    const fetchMessages = async () => {
      setIsLoadingMessages(true)
      try {
        const response = await fetch(`/api/messages?conversationWith=${selectedTeacherId}`)
        if (!response.ok) {
          throw new Error(`Failed to fetch messages: ${response.status}`)
        }

        const data = await response.json()
        console.log("Messages data:", data)

        if (data.success && Array.isArray(data.data)) {
          setCurrentMessages(data.data)
        } else {
          console.error("Messages data is invalid:", data)
          setCurrentMessages([])
        }
      } catch (error) {
        console.error("Error fetching messages:", error)
        toast({
          title: "Error",
          description: "Failed to load messages. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoadingMessages(false)
      }
    }

    fetchMessages()
  }, [selectedTeacherId, toast])

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [currentMessages])

  const handleSendMessage = async () => {
    if (!selectedTeacherId || !message.trim()) {
      return
    }

    setIsSending(true)
    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          recipientId: selectedTeacherId,
          content: message.trim(),
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || `Failed to send message: ${response.status}`)
      }

      const data = await response.json()
      console.log("Message sent:", data)

      // Add the new message to the current messages
      if (data.success && data.message) {
        setCurrentMessages((prev) => [...prev, data.message])
        setMessage("")

        // Update conversations list
        const updatedConversations = [...conversations]
        const existingConversation = updatedConversations.find((conv) => conv.user.id === selectedTeacherId)

        if (existingConversation) {
          existingConversation.lastMessage = data.message
        } else {
          const teacher = teachers.find((t) => t.id === selectedTeacherId || t.userId === selectedTeacherId)
          if (teacher) {
            updatedConversations.push({
              user: {
                id: teacher.id || teacher.userId,
                name: teacher.user?.name || `${teacher.firstName || ""} ${teacher.lastName || ""}`,
                role: "TEACHER",
              },
              lastMessage: data.message,
              unreadCount: 0,
            })
          }
        }

        setConversations(updatedConversations)
      }

      toast({
        title: "Success",
        description: "Message sent successfully.",
      })
    } catch (error) {
      console.error("Error sending message:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSending(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  const getTeacherName = (teacherId: string) => {
    const teacher = teachers.find((t) => t.id === teacherId || t.userId === teacherId)
    if (teacher) {
      if (teacher.user?.name) {
        return teacher.user.name
      } else if (teacher.firstName || teacher.lastName) {
        return `${teacher.firstName || ""} ${teacher.lastName || ""}`
      }
    }
    return "Unknown Teacher"
  }

  const getConversationName = (conversation: any) => {
    if (conversation.user?.name) {
      return conversation.user.name
    } else if (conversation.user?.firstName || conversation.user?.lastName) {
      return `${conversation.user?.firstName || ""} ${conversation.user?.lastName || ""}`
    }
    return "Unknown Contact"
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Messages</h1>
        <p className="text-muted-foreground">Communicate with your child's teachers</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>New Message</CardTitle>
            <CardDescription>Send a message to a teacher</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="teacher">Select Teacher</Label>
                <Select value={selectedTeacherId} onValueChange={setSelectedTeacherId} disabled={isLoadingTeachers}>
                  <SelectTrigger>
                    <SelectValue placeholder={isLoadingTeachers ? "Loading teachers..." : "Select a teacher"} />
                  </SelectTrigger>
                  <SelectContent>
                    {isLoadingTeachers ? (
                      <div className="flex items-center justify-center p-2">
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        Loading teachers...
                      </div>
                    ) : teachers.length > 0 ? (
                      teachers.map((teacher) => (
                        <SelectItem key={teacher.id || teacher.userId} value={teacher.id || teacher.userId}>
                          {teacher.user?.name || `${teacher.firstName || ""} ${teacher.lastName || ""}`}
                          {teacher.department ? ` - ${teacher.department}` : ""}
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="no-teachers" disabled>
                        No teachers available
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder="Type your message here..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="min-h-[150px]"
                  disabled={!selectedTeacherId || isSending}
                />
              </div>

              <Button
                className="w-full"
                onClick={handleSendMessage}
                disabled={!selectedTeacherId || !message.trim() || isSending}
              >
                {isSending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Send Message
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>
              {selectedTeacherId ? `Conversation with ${getTeacherName(selectedTeacherId)}` : "Message History"}
            </CardTitle>
            <CardDescription>
              {selectedTeacherId ? "Your conversation history" : "Select a teacher to view or start a conversation"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!selectedTeacherId ? (
              <div className="space-y-4">
                {isLoadingMessages ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin mr-2" />
                    Loading conversations...
                  </div>
                ) : conversations.length > 0 ? (
                  conversations.map((conversation) => (
                    <div
                      key={conversation.user.id}
                      className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                      onClick={() => setSelectedTeacherId(conversation.user.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <User className="h-8 w-8 text-gray-400 mr-2" />
                          <div>
                            <p className="font-medium">{getConversationName(conversation)}</p>
                            <p className="text-sm text-muted-foreground truncate max-w-[200px]">
                              {conversation.lastMessage?.content || "No messages yet"}
                            </p>
                          </div>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {conversation.lastMessage?.createdAt ? formatDate(conversation.lastMessage.createdAt) : ""}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-muted-foreground py-8">
                    No conversations yet. Start a new message by selecting a teacher.
                  </p>
                )}
              </div>
            ) : (
              <div className="space-y-4 max-h-[500px] overflow-y-auto">
                {isLoadingMessages ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin mr-2" />
                    Loading messages...
                  </div>
                ) : currentMessages.length > 0 ? (
                  currentMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.senderId === session?.user.id ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          msg.senderId === session?.user.id ? "bg-blue-100 text-blue-800" : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <User className="h-4 w-4" />
                          <span className="font-medium">
                            {msg.senderId === session?.user.id ? "You" : getTeacherName(msg.senderId)}
                          </span>
                          <span className="text-xs text-muted-foreground">{formatDate(msg.createdAt)}</span>
                        </div>
                        <p>{msg.content}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-muted-foreground py-8">
                    No messages yet. Start the conversation by sending a message.
                  </p>
                )}
                <div ref={messagesEndRef} />
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
